<?php

class Import_Block_Form extends Core_Block_Template
{
    public function __construct()
    {
        $this->setTemplate("import/form.phtml");
    }
}
?>