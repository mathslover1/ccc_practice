<?php 

class Core_Model_Resource_Collection_Abstract{

}

?>