<?php

class Sales_Model_Resource_Collection_Quote_Shipping extends Core_Model_Resource_Collection_Abstract
{
    

}

