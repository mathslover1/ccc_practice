<?php

class Sales_Model_Quote_Address
{

}


?>