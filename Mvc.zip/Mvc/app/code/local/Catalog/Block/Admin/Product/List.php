<?php
class Catalog_Block_Admin_Product_List {
    
}
?>