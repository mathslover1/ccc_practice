<?php
class Catalog_Model_Category {
    
}
?>