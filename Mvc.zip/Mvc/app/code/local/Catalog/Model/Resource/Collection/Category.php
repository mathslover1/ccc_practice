<?php

class Catalog_Model_Resource_Collection_Category extends Core_Model_Resource_Collection_Abstract{
    
}

?>