<?php
class Admin_Model_Resource_Collection_Admin extends Core_Model_Resource_Collection_Abstract {
    
}
?>