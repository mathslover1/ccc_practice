<?php 

class Customer_Block_Password extends Core_Block_Template {
    public function __construct(){
        $this->setTemplate('customer/account/password.phtml');
    }
    
}
?>