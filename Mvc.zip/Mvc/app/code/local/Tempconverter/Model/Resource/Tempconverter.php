<?php
class Tempconverter_Model_Resource_Tempconverter extends Core_Model_Resource_Abstract{

    public function __construct()
    {
        $this->init('ccc_temp_converter', 'id');
    }
}
?>